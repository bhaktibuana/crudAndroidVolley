package com.example.volleycrudmysql;

public class DbContract {
    public static final String SERVER_GET_URL = "http://192.168.1.14/nama_api/readData.php";
    public static final String SERVER_POST_URL = "http://192.168.1.14/nama_api/createData.php";
    public static final String SERVER_PUT_URL = "http://192.168.1.14/nama_api/updateData.php";
    public static final String SERVER_DELETE_URL = "http://192.168.1.14/nama_api/deleteData.php";
}
