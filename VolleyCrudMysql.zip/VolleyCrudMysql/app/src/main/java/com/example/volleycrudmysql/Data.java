package com.example.volleycrudmysql;

public class Data {

    private String id, nama;

    Data(String id, String nama) {
        this.setId(id);
        this.setNama(nama);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
}
